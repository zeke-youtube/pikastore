import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QToolBar, QAction, QLineEdit,
    QTabWidget, QWidget, QVBoxLayout, QDockWidget
)
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtCore import QUrl, QDir, Qt
from PyQt5.QtGui import QIcon


class BrowserTab(QWidget):
    def __init__(self, url):
        super().__init__()
        layout = QVBoxLayout(self)
        self.browser = QWebEngineView()
        self.browser.setUrl(url)
        layout.addWidget(self.browser)
        self.setLayout(layout)


class ZekeBrowser(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ZekeBrowser")
        self.setGeometry(100, 100, 1200, 800)
        self.setWindowIcon(QIcon("zekebro.ico"))
        self.current_theme = "light"

        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.tabs.removeTab)
        self.tabs.currentChanged.connect(self.update_url_bar)
        self.setCentralWidget(self.tabs)

        self.toolbar = QToolBar("Navigation")
        self.addToolBar(self.toolbar)

        # Navigation buttons
        back = QAction("Back", self)
        back.triggered.connect(lambda: self.current_browser().back())
        self.toolbar.addAction(back)

        forward = QAction("Forward", self)
        forward.triggered.connect(lambda: self.current_browser().forward())
        self.toolbar.addAction(forward)

        reload = QAction("Reload", self)
        reload.triggered.connect(lambda: self.current_browser().reload())
        self.toolbar.addAction(reload)

        self.url_bar = QLineEdit()
        self.url_bar.returnPressed.connect(self.handle_url)
        self.toolbar.addWidget(self.url_bar)

        new_tab = QAction("+", self)
        new_tab.triggered.connect(self.add_tab)
        self.toolbar.addAction(new_tab)

        theme_toggle = QAction("🎨 Theme", self)
        theme_toggle.triggered.connect(self.cycle_theme)
        self.toolbar.addAction(theme_toggle)

        ai_toggle = QAction("🧠 AI", self)
        ai_toggle.triggered.connect(self.toggle_ai_sidebar)
        self.toolbar.addAction(ai_toggle)

        self.add_tab()

    def local_url(self, name):
        return QUrl.fromLocalFile(QDir.current().filePath(name))

    def add_tab(self, url=None):
        url = url or self.local_url("zekehome.html")
        tab = BrowserTab(url)
        index = self.tabs.addTab(tab, "New Tab")
        self.tabs.setCurrentIndex(index)

        tab.browser.urlChanged.connect(lambda u, i=index: self.update_display_url(i, u))
        tab.browser.loadFinished.connect(lambda _, i=index: self.tabs.setTabText(i, tab.browser.title()))

    def handle_url(self):
        text = self.url_bar.text().strip().lower()
        if text == "zeke://home":
            self.add_tab(self.local_url("zekehome.html"))
        elif not text.startswith("http"):
            self.add_tab(QUrl("https://www.google.com/search?q=" + text))
        else:
            self.add_tab(QUrl(text))

    def update_display_url(self, index, url):
        if self.tabs.currentIndex() != index:
            return
        s = url.toString()
        self.url_bar.setText("zeke://home" if s.endswith("zekehome.html") else s)

    def update_url_bar(self, index):
        browser = self.current_browser()
        if browser:
            u = browser.url().toString()
            self.url_bar.setText("zeke://home" if u.endswith("zekehome.html") else u)

    def current_browser(self):
        tab = self.tabs.currentWidget()
        return tab.browser if tab else None

    def cycle_theme(self):
        if self.current_theme == "light":
            self.setStyleSheet("""
                QMainWindow {
                    background-color: #fff9cc;
                    color: #3a3a00;
                }
                QToolBar, QLineEdit {
                    background-color: #fef5a6;
                    color: #2a2a00;
                }
            """)
            self.current_theme = "pika"
        else:
            self.setStyleSheet("")
            self.current_theme = "light"
        self.apply_theme_to_web()

    def apply_theme_to_web(self):
        browser = self.current_browser()
        if not browser:
            return

        css = {
            "pika": "body { background-color: #fff9cc; color: #3a3a00; } a { color: #cc8800; }",
            "light": "body { background-color: white; color: black; } a { color: #0066cc; }"
        }.get(self.current_theme, "")

        js = f"""
            (function() {{
                let style = document.getElementById("zeke-style");
                if (!style) {{
                    style = document.createElement("style");
                    style.id = "zeke-style";
                    document.head.appendChild(style);
                }}
                style.innerHTML = `{css}`;
            }})();
        """
        browser.page().runJavaScript(js)

    def toggle_ai_sidebar(self):
        if hasattr(self, "ai_sidebar") and self.ai_sidebar.isVisible():
            self.ai_sidebar.hide()
        else:
            if not hasattr(self, "ai_sidebar"):
                self.ai_sidebar = QDockWidget("Gemini AI", self)
                self.ai_sidebar.setAllowedAreas(Qt.RightDockWidgetArea)

                self.ai_view = QWebEngineView()
                self.ai_view.setUrl(QUrl("https://gemini.google.com"))
                self.ai_sidebar.setWidget(self.ai_view)

                self.addDockWidget(Qt.RightDockWidgetArea, self.ai_sidebar)

            self.ai_sidebar.show()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    win = ZekeBrowser()
    win.show()
    sys.exit(app.exec_())